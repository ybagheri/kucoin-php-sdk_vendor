<?php

namespace React\Promise\Timer;

if (!function_exists('React\\Promise\\Timer\\timeout')) {
    require __DIR__ . '/functions.php';
}
