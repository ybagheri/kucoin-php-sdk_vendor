<?php

namespace React\Dns\Query;

final class CancellationException extends \RuntimeException
{
}
