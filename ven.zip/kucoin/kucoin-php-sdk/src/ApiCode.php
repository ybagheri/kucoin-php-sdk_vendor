<?php

namespace KuCoin\SDK;

class ApiCode
{
    const SUCCESS = 200000;

    // Account
    const ACCOUNT_EXISTS = 230005;
}